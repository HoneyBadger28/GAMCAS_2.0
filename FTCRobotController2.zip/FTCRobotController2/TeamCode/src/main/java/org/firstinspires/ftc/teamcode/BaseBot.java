/*
SGCM (Smooth Gyro Correction Module)
Developed By FTC Team 'Work In Progress'
*/

package org.firstinspires.ftc.teamcode;
import static java.lang.Math.abs;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;

@TeleOp(name="BaseBot: V0.1", group="BaseBot")

//@Disabled
public class BaseBot extends OpMode {
    @Override
    //StartUp
    public void init() {
        robot.init(hardwareMap);
        telemetry.addData("Console", "Robot Running");
    }

    //Setup Variables
    ElapsedTime Time = new ElapsedTime();
    HardwareBaseBot robot = new HardwareBaseBot();
    private final ElapsedTime runtime = new ElapsedTime();
    Orientation LastAngle = new Orientation();
    double CurrentAngle;
    double OldTime;

    //Setting Control Variables
    double MovementFB;
    double MovementLR;
    double MovementRot;
    double SafeZone;
    boolean Reset = true;
    double Menu;
    double Drivemode;
    double MenuSelect;
    double MenuID;
    String Text;
    double ButtonDown;

    @Override
    public void loop() {


        //(Joysticks must have "-" before the value since the control system is weird like that and reverses the values)
        //SafeZone
        SafeZone = (0.02);
        //Movement forward/Backwards
        MovementFB = (SafeZone(-gamepad1.left_stick_y, SafeZone));
        //Movement Left/Right
        MovementLR = (SafeZone(-gamepad1.left_stick_x, SafeZone));
        //Movement Rotation
        MovementRot = (SafeZone(-gamepad1.right_stick_x, SafeZone));
        //Toggle Menu
        if (gamepad1.back) {
            Menu += 1;
        }
        Menu = Menu % 2;




        telemetry.clearAll();

        if (Menu == 1) {
            if ((gamepad1.dpad_up | gamepad1.dpad_down)) {
                if (ButtonDown == 0) {
                    if (gamepad1.dpad_up) {
                        MenuSelect = +1;
                    }
                    if (gamepad1.dpad_down) {
                        MenuSelect = -1;
                    }
                }
                ButtonDown = 1;
            } else {
                ButtonDown = 0;
            }
            MenuID = 0;
            AddMenuItem("Gyro Correction Drive");
            AddMenuItem("Tank Drive");
            telemetry.addLine("Menu: " + MenuSelect);
            MenuSelect = MenuSelect%MenuID;
        }

        if (Drivemode == 0) {
            //Check if reset, if not then reset
            if (Reset) {
                Reset = false;
                ResetAngle();
                OldTime = Time.seconds();
            }
            //Movement Controller
            double gyroCorrection = 0;
            if (SafeZone(MovementRot, 0.01) != 0) {
                ResetAngle();
                OldTime = Time.seconds();
                gyroCorrection = 0;
            } else {
                if (Time.seconds() - OldTime >= 0.35) {
                    gyroCorrection = SafeZone(getAngle(), 1) / 20;
                } else {
                    ResetAngle();
                }
            }
            robot.RightBack.setPower(-MovementFB - MovementLR - MovementRot + gyroCorrection);
            robot.RightFront.setPower(-MovementFB + MovementLR - MovementRot + gyroCorrection);
            robot.LeftBack.setPower(-MovementFB + MovementLR + MovementRot - gyroCorrection);
            robot.LeftFront.setPower(-MovementFB - MovementLR + MovementRot - gyroCorrection);
        }
    }



    public void AddMenuItem(String Name) {
        Text = "";
        if (MenuSelect == MenuID){
            Text = "> ";
        }
        Text = Text + Name;
        telemetry.addLine(Text);
        if (gamepad1.a & MenuSelect == MenuID){
            Drivemode = MenuID;
        }
        MenuID =+ 1;
    }
    //Initialize Custom Scripts
    public void ResetAngle() {
        LastAngle = robot.IMU1.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
        CurrentAngle = 0;
    }
    public double getAngle() {
        Orientation orientation = robot.IMU1.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
        double deltaAngle = orientation.firstAngle - LastAngle.firstAngle;
        CurrentAngle += deltaAngle;
        LastAngle = orientation;
        return CurrentAngle;
    }
    public double SafeZone(double value, double safeZone) {
        if (abs(value) >= safeZone) {
            return(value);
        } else {
            return(0);
        }
    }
}
