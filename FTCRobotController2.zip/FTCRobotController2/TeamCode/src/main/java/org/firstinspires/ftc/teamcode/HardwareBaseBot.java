package org.firstinspires.ftc.teamcode;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.hardware.bosch.JustLoggingAccelerationIntegrator;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class HardwareBaseBot {
    //Devices / Motors
    public DcMotor  LeftBack    = null;
    public DcMotor  LeftFront   = null;
    public DcMotor  RightBack   = null;
    public DcMotor  RightFront  = null;
    public BNO055IMU IMU1        = null;
    public BNO055IMU IMU2        = null;
    HardwareMap hwMap            = null;
    
    public HardwareBaseBot(){}
    public void init(HardwareMap ahwMap) {
        // Save reference to Hardware map
        hwMap = ahwMap;

        // Define and Initialize Motors
        LeftBack  = hwMap.get(DcMotor.class, "LeftBack");
        LeftFront = hwMap.get(DcMotor.class, "LeftFront");
        RightBack = hwMap.get(DcMotor.class, "RightBack");
        RightFront = hwMap.get(DcMotor.class, "RightFront");
        
        //Define Motor Direction
        LeftBack.setDirection(DcMotor.Direction.FORWARD);
        LeftFront.setDirection(DcMotor.Direction.FORWARD);
        RightBack.setDirection(DcMotor.Direction.REVERSE);
        RightFront.setDirection(DcMotor.Direction.REVERSE);

        // Set all motors to zero power
        LeftBack.setPower(0);
        LeftFront.setPower(0);
        RightBack.setPower(0);
        RightFront.setPower(0);

        // Set all motors to run without encoders.
        LeftBack.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        LeftFront.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        RightBack.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        RightFront.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.angleUnit = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.calibrationDataFile = "BNO055IMUCalibration.json";

        IMU1 = hwMap.get(BNO055IMU.class, "IMU1");
        IMU1.initialize(parameters);
        IMU2 = hwMap.get(BNO055IMU.class, "IMU2");
        IMU2.initialize(parameters);
    }
 }